package com.training.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleController {
	
	@GetMapping("/greeting")
	public String forEveryOne() {
		return "This is data anyone can access!!";
	}
	
	@GetMapping("/securegreeting")
	public String forLoggedInUser() {
		return "This is data only logged in users can access!!";
	}
	
	@GetMapping("/admin/greeting")
	public String forAdmin() {
		return "This is data only admin can access!!";
	}
}
