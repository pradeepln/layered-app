package com.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CiscoAug22AppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CiscoAug22AppApplication.class, args);
	}

}
