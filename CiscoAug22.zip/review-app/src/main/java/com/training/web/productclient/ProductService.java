package com.training.web.productclient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("product-app")
public interface ProductService {
	
	// GET /products
	@GetMapping("/products")
	public List<Product> getAllProducts();
	
	// GET /products/{id}
	@GetMapping("/products/{id}")
	public Product getProductById(@PathVariable("id") int id);
}
