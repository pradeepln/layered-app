package com.training.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.training.dal.ReviewRepository;
import com.training.domain.Review;
import com.training.web.productclient.Product;
import com.training.web.productclient.ProductService;

@RestController
public class ReviewController {
	
	@Autowired
	ReviewRepository dao;
	
	@Autowired
	ProductService productService;
	
	@PostMapping("/reviews")
	public ResponseEntity addNewReview(@RequestBody Review r){
		int pid = r.getPid();
		
		try {
			Product p = productService.getProductById(pid);
			Review added = dao.save(r);
			return new ResponseEntity(r,HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity("Product with id "+pid+" does not Exist!!", HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/reviews")
	public List<Review> getByPid(@RequestParam("pid") int pid){
		return dao.findByPid(pid);
	}

}
