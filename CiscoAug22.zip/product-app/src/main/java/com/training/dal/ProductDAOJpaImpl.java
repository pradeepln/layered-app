package com.training.dal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.training.domain.Product;

@Transactional
@Repository
@Primary
public class ProductDAOJpaImpl implements ProductDAO{
	
	@Autowired
	EntityManager em;
	
	//check to see if caller has done tx.begin, if not, do a tx.begin
	@Override
	public Product save(Product toBeSaved) {
		//toBeSaved --> new/transient
		em.persist(toBeSaved);
		//toBeSaved --> managed		
		//toBeSaved.setPrice(99995);
		return toBeSaved;
	}
	//check to see if i did tx.begin, then tx.commit

	@Override
	public Product findById(int id) {
		Product p = em.find(Product.class, id);
		// p -> managed
		return p;
	}

	@Override
	public List<Product> findAll() {
		Query q = em.createQuery("select p fRoM Product as p");
		return q.getResultList();
	}

	@Override
	public void deleteById(int id) {
		Query q = em.createQuery("delete from Product p where p.id=:idParam");
		q.setParameter("idParam", id);
		q.executeUpdate();
//		Product p = em.find(Product.class, id);
//		em.remove(p);
	}

}
