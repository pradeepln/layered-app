package com.training.dal.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.training.domain.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{

	public List<Product> findByName(String name);
	public List<Product> findByNameLike(String nameLike);
	public List<Product> findByPriceLessThan(float p);
	
	@Query("select p from Product as p where p.qoh>:qohParam")
	public List<Product> myComplexQuery(@Param("qohParam") int i);
}
