package com.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;

import com.training.dal.repo.ProductRepository;
import com.training.domain.Product;
import com.training.ui.ProductConsoleUI;

@EnableDiscoveryClient
@SpringBootApplication
public class ProductAppApplication {

	public static void main(String[] args) {
		ApplicationContext springContainer = 
				SpringApplication.run(ProductAppApplication.class, args);
//		ProductConsoleUI ui = springContainer.getBean(ProductConsoleUI.class);
//		ui.createProductWithUI();
		
		//testRepo(springContainer);
	}

	private static void testRepo(ApplicationContext springContainer) {
		
		ProductRepository repo = springContainer.getBean(ProductRepository.class);
		
		System.out.println("The repo bean is actually of type: "+repo.getClass().getName());
		
		Product sample = new Product("repo", 10001, 12);
		
		Product saved = repo.save(sample);
		System.out.println("saved using repo ---> "+saved.getId());
	}

}
