package com.training.ui;

import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.training.domain.Product;
import com.training.service.ProductService;

@Component
public class ProductConsoleUI {
	
	ProductService service;// = new ProductServiceImpl();
	
	
	@Autowired
	public void setService(ProductService service) { // service
		this.service = service;
	}
	
//	@PostConstruct
//	public void init() {
//		Product aSample = new Product("test", 10000, 1);
//		service.addProduct(aSample);
//		System.out.println("<<<<<<<<<<< UI Bean initialized! >>>>>>>>>>>");
//	}
//	
	
	public void createProductWithUI() {
		
		Scanner kb = new Scanner(System.in);
		
		System.out.println("Enter a name:");
		String name = kb.nextLine();
		System.out.println("Enter a price:");
		float price = Float.parseFloat(kb.nextLine());
		System.out.println("Enter a QoH:");
		int qoh = Integer.parseInt(kb.nextLine());
		
		Product p = new Product(name, price, qoh);
		
		int id = service.addProduct(p);
		
		System.out.println("Created Product with ID: "+id);
		
	}

}
