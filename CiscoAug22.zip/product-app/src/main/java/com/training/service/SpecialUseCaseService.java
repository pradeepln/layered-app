package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.training.dal.ProductDAO;
import com.training.dal.ProductDAOInMemImpl;

@Service
public class SpecialUseCaseService {

	ProductDAO dao;
	
	@Qualifier("altProductDAO")
	@Autowired
	public void setDao(ProductDAO dao) {
		this.dao = dao;
		System.out.println("-----------> The type of DAO is "+dao.getClass().getName());
	}
	
}
