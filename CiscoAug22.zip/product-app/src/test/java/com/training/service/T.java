package com.training.service;

import java.lang.reflect.Method;

import org.springframework.beans.factory.annotation.Autowired;

public class T {

	public static void main(String[] args) {
		ProductServiceImpl obj = new ProductServiceImpl();

		Class classOfSvc = obj.getClass();
		
		Method[] methods = classOfSvc.getDeclaredMethods();
		for(Method m : methods) {
			Autowired aw = m.getAnnotation(Autowired.class);
			if(aw != null) {
				//logic for DI
			}
		}
	}

}
