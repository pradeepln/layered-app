package com.training.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.training.dal.ProductDAO;
import com.training.domain.Product;

class MockitoBasedProductServiceImplTest {

	//Test Doubles, Duck Typing
	//Fast Independent Repeatable Self-validating Timely/thorough
	@Test
	void addProduct_Returns_Valid_ID_When_Value_GTEQ_Min_Value() {
		//AAA
		//Arrange
		ProductServiceImpl objectUnderTest = new ProductServiceImpl();
		Product argToTestMethod = new Product("test", ProductServiceImpl.MIN_VALUE, 1);
		
		Product returnFromMock = new Product("test", ProductServiceImpl.MIN_VALUE, 1);
		returnFromMock.setId(1);
		
		ProductDAO mockDAO = Mockito.mock(ProductDAO.class);
		Mockito.when(mockDAO.save(argToTestMethod)).thenReturn(returnFromMock);
		
		objectUnderTest.setDao(mockDAO);
		
		//Act
		int id = objectUnderTest.addProduct(argToTestMethod);
		//Assert
		assertTrue(id > 0);
	}

}
