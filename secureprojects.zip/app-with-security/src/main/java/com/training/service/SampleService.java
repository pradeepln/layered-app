package com.training.service;

import javax.annotation.security.RolesAllowed;

import org.springframework.stereotype.Service;

@Service
public class SampleService {
	
	
	
	public String dataForUser() {
		return "Hello, this is allowed for loggen in users";
	}
	
	
	
	@RolesAllowed("ADMIN")
	public String dataForAdmin() {
		return "Hello, this is allowed for admin only";
	}

}
