package com.training.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.service.SampleService;
//https://codeshare.io/LweeQk
@RestController
public class SampleController {
	
	@Autowired
	SampleService service;
	
	@GetMapping("/greeting")
	public String aMethodForAll() {
		return "Hello, this is allowed for all";
	}
	
	
	@GetMapping("/securegreeting")
	public String aMethodForUsers() {
		
		try {
			String data = service.dataForAdmin();
		} catch (Exception e) {
			return " Access Denied with exception ---> "+e.getClass().getName();
		}
		return service.dataForUser();
	}
	
	
	@GetMapping("/managementops/someop")
	public String aMethodForAadmin() {
		return service.dataForAdmin();
	}

}
